# GlobalWire — Netlify-ready edition

World news, continuously — aggregated from **36 public source feeds across 9 categories**,
refreshing **every 60 minutes**, now deployable to Netlify's serverless platform.

## Architecture (why it was rebuilt)

Netlify does **not** run long-lived servers, so the original Python `server.py`
(port 8000, in-memory hourly refresher) cannot be uploaded as-is. This edition
splits the app into exactly what Netlify runs natively:

```
public/index.html              ← static shell (the same UI you already know)
netlify.toml                    ← publish/functions config + header rules
package.json                    ← one dependency: @netlify/blobs (cache store)
netlify/functions/
├── news.mjs                    ← GET /api/news?category=…  (the data endpoint)
├── status.mjs                  ← GET /api/status           (source health + countdown)
├── refresh.mjs                 ← POST|GET /api/refresh     (force re-crawl)
├── _core.mjs                   ← feed fetcher/parser/aggregator (pure Node, no deps)
└── sources_data.mjs            ← the 36 feeds, generated from ../sources.json
```

**How updates work with no server:**

1. The first visitor after deploy triggers `news.mjs`, which crawls all 36 feeds
   **in parallel** (measured ≈ 1 s end-to-end, far under the 10 s function limit).
2. The result is stored in **Netlify Blobs** with a 60-minute TTL logic.
3. Until expiry, every request is served from cache — memory on a warm instance,
   Blobs on a cold one — and responses also cache at Netlify's CDN edge.
4. After 60 minutes the next request transparently re-crawls. The "Refresh now"
   button hits `/api/refresh`, which forces an immediate re-crawl and cache write.

Result: the site **updates itself forever** with zero processes, zero build minutes,
and only one feed-crawl per hour (the free tier's 125k function invocations/month
is untouched by polling: `/api/status` is read-only and edge-cached, and the
page's poll interval was relaxed from 5 s → 60 s for good measure).

Endpoint shapes are byte-identical to the Python server, so the UI works unchanged.

## Deploy — pick one

### A) Drag & drop (fastest, no account plumbing)
1. Go to <https://app.netlify.com/drop> and drag the **`netlify-deploy.zip`**
   file (created next to this folder).
   Netlify unpacks, installs `@netlify/blobs`, bundles the functions, and deploys.
2. Open the site URL. First page load crawls the feeds (~2 s), subsequent loads
   come from cache. Done.

### B) Netlify CLI
```bash
npx netlify-cli login
npx netlify-cli deploy --prod --dir .
# (run from this folder; zip flow: --dir points at the unzipped folder)
```

### C) Git (best for future edits)
```bash
git init && git add . && git commit -m "GlobalWire netlify edition"
# push to GitHub/GitLab, then in Netlify: Add new site → Import an existing
# project → pick the repo. Build settings are already in netlify.toml.
```

## Verify after deploy

```bash
curl https://YOUR-SITE.netlify.app/api/status
# {"sources_ok":36,"sources_total":36,...}
curl "https://YOUR-SITE.netlify.app/api/news?category=technology" | head -c 300
```

## Optional: pre-warm the cache

Without cron, the first visitor *after each hour* pays ~1 s while the cache
rebuilds — everyone else gets instant loads. If you want even that gone, point
any free cron service (e.g. cron-job.org) at
`https://YOUR-SITE.netlify.app/api/refresh` once per hour. That is all —
no scheduled-function plan needed.

## Editing feeds

Add/remove entries in `sources.json` at the repo root of the original project,
regenerate with:

```bash
python3 - <<'EOF'
import json
src = json.load(open('sources.json'))
js = "// Generated from sources.json — single source of truth for feeds.\n"
js += "export const CATEGORIES = " + json.dumps(list(src.keys())) + ";\n"
js += "export const SOURCES = " + json.dumps(src, indent=2) + ";\n"
js += "export const SOURCE_COUNT = " + str(sum(len(v) for v in src.values())) + ";\n"
open('netlify/functions/sources_data.mjs','w').write(js)
EOF
```

…then redeploy. Or edit `netlify/functions/sources_data.mjs` directly.

## Local development

The Python server (`../server.py`) stays as the local dev version on port 8000.
To test the functions locally: `npm install && npx netlify-cli dev`
(serves exactly the deployed architecture on <http://localhost:8888>).

---
*All content belongs to and links back to the original publishers. This is a
personal/educational aggregator — attribute sources respectfully.*
