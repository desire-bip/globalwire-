// Generated from ../sources.json — single source of truth for feeds.
export const CATEGORIES = ["top", "world", "business", "technology", "science", "health", "sports", "entertainment", "politics"];
export const SOURCES = {
  "top": [
    {
      "name": "BBC News",
      "url": "https://feeds.bbci.co.uk/news/rss.xml"
    },
    {
      "name": "Google News",
      "url": "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"
    },
    {
      "name": "NPR",
      "url": "https://feeds.npr.org/1001/rss.xml"
    },
    {
      "name": "NYT Top",
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"
    }
  ],
  "world": [
    {
      "name": "BBC World",
      "url": "https://feeds.bbci.co.uk/news/world/rss.xml"
    },
    {
      "name": "The Guardian World",
      "url": "https://www.theguardian.com/world/rss"
    },
    {
      "name": "NYT World",
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/World.xml"
    },
    {
      "name": "Sky News World",
      "url": "https://feeds.skynews.com/feeds/rss/world.xml"
    }
  ],
  "business": [
    {
      "name": "BBC Business",
      "url": "https://feeds.bbci.co.uk/news/business/rss.xml"
    },
    {
      "name": "GN Business",
      "url": "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-US&gl=US&ceid=US:en"
    },
    {
      "name": "Guardian Business",
      "url": "https://www.theguardian.com/uk/business/rss"
    },
    {
      "name": "MarketWatch",
      "url": "https://feeds.marketwatch.com/marketwatch/topstories/"
    }
  ],
  "technology": [
    {
      "name": "The Verge",
      "url": "https://www.theverge.com/rss/index.xml"
    },
    {
      "name": "TechCrunch",
      "url": "https://techcrunch.com/feed/"
    },
    {
      "name": "Ars Technica",
      "url": "https://feeds.arstechnica.com/arstechnica/index"
    },
    {
      "name": "Wired",
      "url": "https://www.wired.com/feed/rss"
    }
  ],
  "science": [
    {
      "name": "NASA",
      "url": "https://www.nasa.gov/rss/dyn/breaking_news.rss"
    },
    {
      "name": "ScienceDaily",
      "url": "https://www.sciencedaily.com/rss/top/science.xml"
    },
    {
      "name": "Phys.org",
      "url": "https://phys.org/rss-feed/"
    },
    {
      "name": "Guardian Science",
      "url": "https://www.theguardian.com/science/rss"
    }
  ],
  "health": [
    {
      "name": "NYT Health",
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/Health.xml"
    },
    {
      "name": "BBC Health",
      "url": "https://feeds.bbci.co.uk/news/health/rss.xml"
    },
    {
      "name": "NPR Health",
      "url": "https://feeds.npr.org/1128/rss.xml"
    },
    {
      "name": "Guardian Health",
      "url": "https://www.theguardian.com/society/health/rss"
    }
  ],
  "sports": [
    {
      "name": "BBC Sport",
      "url": "https://feeds.bbci.co.uk/sport/rss.xml"
    },
    {
      "name": "CBS Sports",
      "url": "https://www.cbssports.com/rss/headlines/"
    },
    {
      "name": "GN Sports",
      "url": "https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-US&gl=US&ceid=US:en"
    },
    {
      "name": "Guardian Sport",
      "url": "https://www.theguardian.com/uk/sport/rss"
    }
  ],
  "entertainment": [
    {
      "name": "BBC Entertainment",
      "url": "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml"
    },
    {
      "name": "NYT Arts",
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/Arts.xml"
    },
    {
      "name": "Rolling Stone",
      "url": "https://www.rollingstone.com/feed/"
    },
    {
      "name": "Guardian Culture",
      "url": "https://www.theguardian.com/uk/culture/rss"
    }
  ],
  "politics": [
    {
      "name": "BBC Politics",
      "url": "https://feeds.bbci.co.uk/news/politics/rss.xml"
    },
    {
      "name": "NYT Politics",
      "url": "https://rss.nytimes.com/services/xml/rss/nyt/Politics.xml"
    },
    {
      "name": "Guardian Politics",
      "url": "https://www.theguardian.com/politics/rss"
    },
    {
      "name": "NPR Politics",
      "url": "https://feeds.npr.org/1014/rss.xml"
    }
  ]
};
export const SOURCE_COUNT = 36;
