// GET /api/news?category=x — serves the aggregated news payload.
import { getNewsStore, getFreshPayload, snapshot, REFRESH_SECONDS } from "./_core.mjs";
import { CATEGORIES } from "./sources_data.mjs";

export default async (req, context) => {
  const url = new URL(req.url);
  let category = (url.searchParams.get("category") || "all").toLowerCase();
  if (category !== "all" && !CATEGORIES.includes(category)) category = "all";

  const store = await getNewsStore();
  const { payload } = await getFreshPayload(store);

  const body = snapshot(payload, category);
  const age = Math.max(0, Math.floor(Date.now() / 1000) - payload.built_at_ts);

  return new Response(JSON.stringify(body), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      // Cache at Netlify's edge for the remaining life of this payload — this
      // keeps function invocations (and your quota) low under user traffic.
      "netlify-cdn-cache-control": `public, max-age=${Math.min(300, REFRESH_SECONDS - age || 300)}`,
      "cache-control": "public, max-age=60",
    },
  });
};

export const config = { path: "/api/news" };
