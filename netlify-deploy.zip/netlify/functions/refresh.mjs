// POST (or GET) /api/refresh — force a full crawl right now and store it.
import { getNewsStore, rebuildAll, writeCache } from "./_core.mjs";

export default async (req) => {
  if (!["GET", "POST"].includes(req.method))
    return new Response(JSON.stringify({ error: "method not allowed" }), { status: 405 });

  const store = await getNewsStore();
  const payload = await rebuildAll();
  await writeCache(store, payload);
  const ok = Object.values(payload.status).filter(s => s.ok).length;

  return new Response(
    JSON.stringify({
      ok: true,
      message: "refresh complete",
      sources_ok: ok,
      sources_total: Object.keys(payload.status).length,
      updated_at: payload.built_at_iso,
    }),
    { status: 200, headers: { "content-type": "application/json; charset=utf-8" } }
  );
};

export const config = { path: "/api/refresh" };
