// GlobalWire serverless core — feed fetching, parsing, snapshot building.
// Pure logic, no Netlify imports, so it is testable locally with plain Node.
import { SOURCES, CATEGORIES } from "./sources_data.mjs";

export const REFRESH_SECONDS = 3600; // 1 hour, same behaviour as the Python server
export const FEED_TIMEOUT_MS = 6500; // per-feed network timeout (must fit the 10s function limit)
const ITEMS_PER_FEED = 25;
const ITEMS_PER_CATEGORY = 60;
const ITEMS_ALL = 120;

const UA =
  "Mozilla/5.0 (compatible; GlobalWire/1.0; +news-aggregator) " +
  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

// ---------------------------------------------------------------------------
// tiny XML helpers (feed-specific, tolerant of CDATA + namespaces)
function stripCdata(s) {
  s = (s || "").trim();
  return s.startsWith("<![CDATA[") ? s.slice(9, -3) : s;
}
const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
function decodeEntities(s) {
  return (s || "").replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (_, e) => {
    if (e[0] === "#")
      return String.fromCodePoint(
        e[1] === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)
      );
    return ENTITIES[e] ?? e;
  });
}
function tagText(block, name) {
  const m = block.match(
    new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}>`, "i")
  );
  return m ? stripCdata(m[1]) : "";
}
function attrOf(tagMarkup, name) {
  const m = tagMarkup.match(new RegExp(`${name}="([^"]+)"`, "i"));
  return m ? m[1] : "";
}
function* matchBlocks(xml, tag) {
  const re = new RegExp(
    `<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>|<${tag}\\b[^>]*/>`,
    "gi"
  );
  let m;
  while ((m = re.exec(xml)) !== null) yield m[0];
}

// ---------------------------------------------------------------------------
function stripHtml(text, limit = 280) {
  let t = decodeEntities((text || "").replace(/<[^>]+>/g, " "));
  t = t.replace(/\s+/g, " ").trim();
  return t.length > limit ? t.slice(0, limit - 1) + "…" : t;
}
function parseDate(raw) {
  if (!raw) return null;
  const t = Date.parse(raw.trim());
  return Number.isNaN(t) ? null : Math.floor(t / 1000);
}
function findImage(block, descHtml) {
  // media:thumbnail / media:content url attribute
  for (const m of block.matchAll(/<media:(?:thumbnail|content)\b[^>]*>/gi)) {
    const url = attrOf(m[0], "url");
    const type = attrOf(m[0], "type");
    const medium = attrOf(m[0], "medium");
    if (url.startsWith("http") && (!medium || medium === "image") && (!type || type.startsWith("image")))
      return url;
  }
  // enclosure
  for (const m of block.matchAll(/<enclosure\b[^>]*>/gi)) {
    const url = attrOf(m[0], "url");
    if (attrOf(m[0], "type").startsWith("image") && url.startsWith("http")) return url;
  }
  // first <img> in the description/content html
  const img = (descHtml || "").match(/<img[^>]+src=["']([^"']+)["']/i);
  if (img && img[1].startsWith("http")) return img[1];
  return null;
}

// ---------------------------------------------------------------------------
export function parseFeed(xml, source, category) {
  const now = Math.floor(Date.now() / 1000);
  const out = [];
  const push = (title, url, desc, dateRaw, block) => {
    const d = desc || tagText(block, "description");
    let ts = parseDate(dateRaw) ?? now;
    ts = Math.min(ts, now + 300);
    if (!title || !url.startsWith("http")) return;
    out.push({
      title: stripHtml(title, 200),
      url,
      summary: stripHtml(d),
      published_ts: ts,
      published_at: new Date(ts * 1000).toISOString().slice(0, 19) + "+00:00",
      source,
      category,
      image: findImage(block, d),
    });
  };

  // RSS 2.0
  for (const item of matchBlocks(xml, "item")) {
    const desc =
      tagText(item, "content:encoded") || tagText(item, "description");
    push(
      tagText(item, "title"),
      tagText(item, "link"),
      desc,
      tagText(item, "pubDate") || tagText(item, "dc:date"),
      item
    );
  }
  // Atom
  for (const entry of matchBlocks(xml, "entry")) {
    let link = "";
    for (const m of entry.matchAll(/<([a-zA-Z0-9]+:)?link\b[^>]*>/gi)) {
      const rel = attrOf(m[0], "rel");
      if (!rel || rel === "alternate") {
        link = attrOf(m[0], "href");
        if (link) break;
      }
    }
    const desc = tagText(entry, "summary") || tagText(entry, "content");
    push(
      tagText(entry, "title"),
      link,
      desc,
      tagText(entry, "published") || tagText(entry, "updated"),
      entry
    );
  }
  return out.slice(0, ITEMS_PER_FEED);
}

// ---------------------------------------------------------------------------
async function fetchOne(feed, category) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FEED_TIMEOUT_MS);
  try {
    const res = await fetch(feed.url, {
      headers: {
        "User-Agent": UA,
        Accept: "application/rss+xml,application/atom+xml,application/xml,text/xml,*/*",
      },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const xml = await res.text();
    return { name: feed.name, items: parseFeed(xml, feed.name, category), error: null };
  } catch (e) {
    const err = e.name === "AbortError" ? "timeout" : String(e).slice(0, 120);
    return { name: feed.name, items: [], error: err };
  } finally {
    clearTimeout(timer);
  }
}

// One full refresh cycle: all feeds in parallel -> merged, sorted, deduped payload.
export async function rebuildAll() {
  const jobs = [];
  for (const [cat, feeds] of Object.entries(SOURCES))
    for (const f of feeds) jobs.push([f, cat]);

  const results = await Promise.all(jobs.map(([f, c]) => fetchOne(f, c)));

  const status = {};
  const byCat = Object.fromEntries(CATEGORIES.map(c => [c, []]));
  results.forEach((r, i) => {
    const cat = jobs[i][1];
    status[r.name] = { ok: !r.error, count: r.items.length, category: cat, error: r.error };
    byCat[cat].push(...r.items);
  });

  for (const cat of CATEGORIES) {
    const seen = new Set();
    const deduped = [];
    for (const it of byCat[cat].sort((a, b) => b.published_ts - a.published_ts)) {
      const key = it.url.split("#")[0];
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(it);
    }
    byCat[cat] = deduped.slice(0, ITEMS_PER_CATEGORY);
  }

  const now = Math.floor(Date.now() / 1000);
  return {
    built_at_ts: now,
    built_at_iso: new Date(now * 1000).toISOString().slice(0, 19) + "+00:00",
    items_by_cat: byCat,
    status,
  };
}

// ---------------------------------------------------------------------------
export function snapshot(payload, category) {
  let items;
  if (category === "all") {
    items = Object.values(payload.items_by_cat)
      .flat()
      .sort((a, b) => b.published_ts - a.published_ts)
      .slice(0, ITEMS_ALL);
  } else {
    items = payload.items_by_cat[category] || [];
  }
  return {
    updated_at: payload.built_at_iso,
    updated_ts: payload.built_at_ts,
    next_refresh_in: Math.max(0, payload.built_at_ts + REFRESH_SECONDS - Math.floor(Date.now() / 1000)),
    category,
    categories: CATEGORIES,
    count: items.length,
    items,
  };
}

export function statusSnapshot(payload) {
  const sources = payload?.status || {};
  const ok = Object.values(sources).filter(s => s.ok).length;
  return {
    updated_at: payload ? payload.built_at_iso : null,
    next_refresh_in: payload
      ? Math.max(0, payload.built_at_ts + REFRESH_SECONDS - Math.floor(Date.now() / 1000))
      : 0,
    sources_ok: ok,
    sources_total: Object.keys(sources).length,
    refresh_interval_seconds: REFRESH_SECONDS,
    sources,
  };
}

// ---------------------------------------------------------------------------
// Two-tier caching: warm instance memory + a Netlify Blobs store shared by all
// instances, so a refresh costs one crawl per hour, not one per request.
const BLOB_KEY = "cache-v2";
globalThis.__gwCache ??= { payload: null };

export async function readCache(store) {
  const mem = globalThis.__gwCache.payload;
  if (mem) return mem;
  if (!store) return null;
  try {
    const blob = await store.get(BLOB_KEY, { type: "json" });
    if (blob && blob.built_at_ts) {
      globalThis.__gwCache.payload = blob;
      return blob;
    }
  } catch { /* no cache yet */ }
  return null;
}

export async function writeCache(store, payload) {
  globalThis.__gwCache.payload = payload;
  if (!store) return;
  try { await store.setJSON(BLOB_KEY, payload); } catch { /* memory-only */ }
}

export function isFresh(payload) {
  return (
    payload &&
    payload.built_at_ts + REFRESH_SECONDS > Math.floor(Date.now() / 1000)
  );
}

// Shared fetch-or-rebuild logic for every endpoint.
export async function getFreshPayload(store, { force = false } = {}) {
  const cached = await readCache(store);
  if (!force && isFresh(cached)) return { payload: cached, rebuilt: false };
  let payload;
  try {
    payload = await rebuildAll();
  } catch (e) {
    if (cached) return { payload: cached, rebuilt: false }; // serve stale on total failure
    throw e;
  }
  await writeCache(store, payload);
  return { payload, rebuilt: true };
}

// Optional Netlify Blobs store. Dynamic import keeps this module runnable
// outside Netlify (local tests) without the @netlify/blobs dependency.
export async function getNewsStore() {
  try {
    const mod = await import("@netlify/blobs");
    return mod.getStore({ name: "globalwire" });
  } catch {
    return null;
  }
}
