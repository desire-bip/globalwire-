// GET /api/status — per-source health + countdown. Never triggers a crawl:
// read-only, so the page's periodic polls stay cheap.
import { getNewsStore, readCache, statusSnapshot } from "./_core.mjs";

export default async () => {
  const store = await getNewsStore();
  const payload = await readCache(store);
  return new Response(JSON.stringify(statusSnapshot(payload)), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "public, max-age=30",
    },
  });
};

export const config = { path: "/api/status" };
